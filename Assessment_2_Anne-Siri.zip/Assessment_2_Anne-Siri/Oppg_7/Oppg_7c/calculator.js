const add = require('./add.js');
const subtract = require('./sub.js');

console.log(add(1, 2)); // => 3
console.log(subtract(4, 2)); // => 2 