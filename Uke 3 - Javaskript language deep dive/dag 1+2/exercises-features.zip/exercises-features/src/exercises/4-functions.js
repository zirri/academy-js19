var {
  testCase,
  assert,
  assertEquals
} = require('../lib/test-runner');

/**
 * DESCRIPTION:
 * Replace all occurrences of 'REPLACE_ME' in the unit tests below to make them
 * all pass (they should be green).
 * HINT
 * If you get stuck, you can replace assert(a == b) with assertEquals(b, a).
 * That way the error message in the browser will be more specific. However,
 * give it a try before you do this, as in most cases this will give you the
 * answer flat out.
 */
var REPLACE_ME = '...';

testCase('Functions', {
  'Declare a function that takes no parameters': function() {
    // Fill in necessary statement(s) to pass the assertions below


    assert(typeof myFunc == "function", "should be a function");
    assert(myFunc.length == 0, "should have no specified arguments");
    assert(myFunc.name == "myFunc", "should have correct name");
  },

  'Create a named function expression that takes 3 parameters': function() {
    // Fill in necessary statement(s) to pass the assertions below


    assert(typeof myFunc == "function", "should be a function");
    assert(myFunc.length == 3, "should have 3 specified arguments");
    assert(myFunc.name == "myAwesomeFunction", "should have the correct name");
  },

  'Function scope 1': function() {
    // Fill in necessary statement(s) to pass the assertions below

    /**
    * For clarity/readability, the function
    * without the assertions is in the
    * comment below
    *
    *
    * var a = 5;
    * var b = 10;
    * var c = 15;
    *
    * function doSometing() {
    *   var a = 20;
    *
    *   function doSomethingElse() {
    *     var c = 30;
    *   }
    *
    *   doSomethingElse();
    * }
    *
    * doSomething();
    */

    var a = 5;
    var b = 10;
    var c = 15;

    function doSomething() {
      var a = 20;

                                        /* assertions */
                                        assert(a == REPLACE_ME, "1");
                                        assert(b == REPLACE_ME, "2");
                                        assert(c == REPLACE_ME, "3");
                                        /* .......... */

      function doSomethingElse() {
        var c = 30;

                                        /* assertions */
                                        assert(a == REPLACE_ME, "4");
                                        assert(b == REPLACE_ME, "5");
                                        assert(c == REPLACE_ME, "6");
                                        /* .......... */
      }

                                        /* assertions */
                                        assert(a == REPLACE_ME, "7");
                                        assert(b == REPLACE_ME, "8");
                                        assert(c == REPLACE_ME, "9");
                                        /* .......... */

      doSomethingElse();

                                        /* assertions */
                                        assert(a == REPLACE_ME, "10");
                                        assert(b == REPLACE_ME, "11");
                                        assert(c == REPLACE_ME, "12");
                                        /* .......... */
    }

                                        /* assertions */
                                        assert(a == REPLACE_ME, "13");
                                        assert(b == REPLACE_ME, "14");
                                        assert(c == REPLACE_ME, "15");
                                        /* .......... */

    doSomething();

                                        /* assertions */
                                        assert(a == REPLACE_ME, "16");
                                        assert(b == REPLACE_ME, "17");
                                        assert(c == REPLACE_ME, "18");
                                        /* .......... */
  },

  'Function scope 2': function() {
    // Fill in necessary statement(s) to pass the assertions below

    /**
    * For clarity/readability, the function
    * without the assertions is in the
    * comment below
    *
    *
    * var a = 5;
    * var b = 10;
    * var c = 15;
    *
    * function doSometing() {
    *   var a = 20;
    *   var b = 50;
    *
    *   function doSomethingElse() {
    *     var c = 30;
    *     b = 100;
    *   }
    *
    *   doSomethingElse();
    *
    *   c = 300;
    * }
    *
    * doSomething();
    */

    var a = 5;
    var b = 10;
    var c = 15;

    function doSomething() {
      var a = 20;
      var b = 50;

                                        /* assertions */
                                        assert(a == REPLACE_ME, "1");
                                        assert(b == REPLACE_ME, "2");
                                        assert(c == REPLACE_ME, "3");
                                        /* .......... */

      function doSomethingElse() {
        var c = 30;
        b = 100;

                                        /* assertions */
                                        assert(a == REPLACE_ME, "4");
                                        assert(b == REPLACE_ME, "5");
                                        assert(c == REPLACE_ME, "6");
                                        /* .......... */
      }

                                        /* assertions */
                                        assert(a == REPLACE_ME, "7");
                                        assert(b == REPLACE_ME, "8");
                                        assert(c == REPLACE_ME, "9");
                                        /* .......... */

      doSomethingElse();

      c = 300;

                                        /* assertions */
                                        assert(a == REPLACE_ME, "10");
                                        assert(b == REPLACE_ME, "11");
                                        assert(c == REPLACE_ME, "12");
                                        /* .......... */
    }

                                        /* assertions */
                                        assert(a == REPLACE_ME, "13");
                                        assert(b == REPLACE_ME, "14");
                                        assert(c == REPLACE_ME, "15");
                                        /* .......... */

    doSomething();

                                        /* assertions */
                                        assert(a == REPLACE_ME, "16");
                                        assert(b == REPLACE_ME, "17");
                                        assert(c == REPLACE_ME, "18");
                                        /* .......... */
  },
});
