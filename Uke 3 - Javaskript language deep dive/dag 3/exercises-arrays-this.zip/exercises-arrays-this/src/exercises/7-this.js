/**
 * Import test framework
 */
var {
  testCase,
  assert,
  assertEquals
} = require('../lib/test-runner');

/**
 * DESCRIPTION:
 * Replace all occurrences of 'REPLACE_ME' in the unit tests below to make them
 * all pass (they should be green).
 * HINT
 * If you get stuck, you can replace assert(a == b) with assertEquals(b, a).
 * That way the error message in the browser will be more specific. However,
 * give it a try before you do this, as in most cases this will give you the
 * answer flat out.
 */
var REPLACE_ME = '...';

/**
 * Exercises
 */
testCase('The meaning of this', {
  'What is this?': function () {
    var person = {
      name: 'Frank',
      getThis: function () {
        return this;
      }
    };

    var getThis = person.getThis;

    var otherPerson = {
      name: 'Anna'
    };

    otherPerson.getThis = person.getThis;

    var completelyDifferentPerson = {
      name: 'Hank',
      getThat: getThis
    };

    /**
     * Assertions that should be fulfilled
     */
    assert(person.getThis() == REPLACE_ME, "1");
    assert(getThis() == REPLACE_ME, "2");
    assert(otherPerson.getThis() == REPLACE_ME, "3");
    assert(completelyDifferentPerson.getThat() == REPLACE_ME, "4");
    assert(getThis.call(otherPerson) == REPLACE_ME, "5");
    assert(otherPerson.getThis.call(person) == REPLACE_ME, "6");
    assert(completelyDifferentPerson.getThat.call(otherPerson) == REPLACE_ME, "7");
    assert(person.getThis.apply(otherPerson) == REPLACE_ME, "8");
    assert(person.getThis.apply() == REPLACE_ME, "9");
  },

  'Bindybind!': function () {
    /**
     * Fill in necessary statement(s) to pass the assertions below
     */
    var person = {
      name: 'Frank',
      getThis: function () {
        return this;
      }
    };

    var frankGetThis = person.getThis.bind(person);

    var otherPerson = {
      name: 'Anna',
      getThis: frankGetThis
    };

    var annaGetThis = otherPerson.getThis.bind(otherPerson);

    /**
     * Assertions that should be fulfilled
     */
    assert(person.getThis() == REPLACE_ME, "1");
    assert(frankGetThis() == REPLACE_ME, "2");
    assert(otherPerson.getThis() == REPLACE_ME, "3");
    assert(annaGetThis() == REPLACE_ME, "4");
  },

  'Mapping assets (with an intermediate self/this)': function () {
    /**
     * Fill in necessary statement(s) to pass the assertions below
     */

    var person = {
      name: 'Hank Moody',
      assets: ['Porsche', 'Sigarette', 'Daughter'],
      mapAssets: function () {
        /**
         * Here's where you need to make changes
         */
        return this.assets.map(function (asset) {
          return this.name + ' has a ' + asset;
        });
      }
    };

    /**
     * Assertions that should be fulfilled
     */
    assert(person.mapAssets()[0] == 'Hank Moody has a Porsche');
    assert(person.mapAssets()[1] == 'Hank Moody has a Sigarette');
    assert(person.mapAssets()[2] == 'Hank Moody has a Daughter');
  },

  'Mapping assets (with bind)': function () {
    /**
     * Fill in necessary statement(s) to pass the assertions below
     */

    var person = {
      name: 'Hank Moody',
      assets: ['Porsche', 'Sigarette', 'Daughter'],
      mapAssets: function () {
        /**
         * Here's where you need to make changes
         */
        return this.assets.map(function (asset) {
          return this.name + ' has a ' + asset;
        });
      }
    };

    /**
     * Assertions that should be fulfilled
     */
    assert(person.mapAssets()[0] == 'Hank Moody has a Porsche');
    assert(person.mapAssets()[1] == 'Hank Moody has a Sigarette');
    assert(person.mapAssets()[2] == 'Hank Moody has a Daughter');
  },

  'Remote execution (with bind)': function () {
    /**
     * Fill in necessary statement(s) to pass the assertions below
     */

    var person = {
      name: 'Hank Moody',
      assets: ['Porsche', 'Sigarette', 'Daughter'],
      mapAssets: function () {
        return this.assets.map(function (asset) {
          return this.name + ' has a ' + asset;
        });
      }
    };

    function remotelyExecute(func) {
      return func();
    }

    var mapAssets = REPLACE_ME;

    /**
     * Assertions that should be fulfilled
     */
    assert(remotelyExecute(mapAssets)[0] == 'Hank Moody has a Porsche');
    assert(remotelyExecute(mapAssets)[1] == 'Hank Moody has a Sigarette');
    assert(remotelyExecute(mapAssets)[2] == 'Hank Moody has a Daughter');
  },

  'Borrowing a function': function () {
    /**
     * Fill in necessary statement(s) to pass the assertions below
     */

    var person = {
      name: 'Hank Moody',
      assets: ['Porsche', 'Sigarette', 'Daughter'],
      mapAssets: function () {
        return this.assets.map(function (asset) {
          return this.name + ' has a ' + asset;
        });
      }
    };

    var otherPerson = {
      name: 'Vince Chase',
      assets: ['Girlfriend', 'Lot of cash', 'Manager']
    };

    /**
     * Assertions that should be fulfilled
     */
    assert(otherPerson.mapAssets()[0] == 'Vince Chase has a Girlfriend');
    assert(otherPerson.mapAssets()[1] == 'Vince Chase has a Lot of cash');
    assert(otherPerson.mapAssets()[2] == 'Vince Chase has a Manager');
  },

  'Borrowing a function (with call)': function () {
    /**
     * Fill in necessary statement(s) to pass the assertions below
     */

    var person = {
      name: 'Hank Moody',
      assets: ['Porsche', 'Sigarette', 'Daughter'],
      mapAssets: function () {
        return this.assets.map(function (asset) {
          return this.name + ' has a ' + asset;
        });
      }
    };

    var otherPerson = {
      name: 'Vince Chase',
      assets: ['Girlfriend', 'Lot of cash', 'Manager']
    };

    var mappedAssets = REPLACE_ME;

    /**
     * Assertions that should be fulfilled
     */
    assert(mappedAssets[0] == 'Vince Chase has a Girlfriend');
    assert(mappedAssets[1] == 'Vince Chase has a Lot of cash');
    assert(mappedAssets[2] == 'Vince Chase has a Manager');
  },

  'Borrowing a function (with apply)': function () {
    /**
     * Fill in necessary statement(s) to pass the assertions below
     */

    var person = {
      name: 'Hank Moody',
      assets: ['Porsche', 'Sigarette', 'Daughter'],
      mapAssets: function () {
        return this.assets.map(function (asset) {
          return this.name + ' has a ' + asset;
        });
      }
    };

    var otherPerson = {
      name: 'Vince Chase',
      assets: ['Girlfriend', 'Lot of cash', 'Manager']
    };

    var mappedAssets = REPLACE_ME;

    /**
     * Assertions that should be fulfilled
     */
    assert(mappedAssets[0] == 'Vince Chase has a Girlfriend');
    assert(mappedAssets[1] == 'Vince Chase has a Lot of cash');
    assert(mappedAssets[2] == 'Vince Chase has a Manager');
  },
});
